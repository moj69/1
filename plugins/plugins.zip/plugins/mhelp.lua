do
local function run(msg,matches)
local reply_id = msg['id']
if not is_momod(msg) and matches[1]== 'help' then
  local alnaze = [[برای استفاده ار دستورات🔹🔧
از این علامات استفاده کنید( ! او / )
✇kickme :اخراج خودتون از گروه
✇rules : ارسال قوانین گروه
✇version : ارسال ورژن ربات
✇channel : ارسال تگ کانال ربات
✇support : ارسال لینک ساپورت ربات
✇date : ارسال تاریخ
✶fullinfo : اطلاعات اضافی شما ↯↯↯↯↯↯تنظیم↯↯↯↯↯↯↯
☆setnkname : اسم شما
☆setage : سن شما
☆setsex : جنس شما(مرد،زن)
☆setnote : پیام اضافه]]
reply_msg(reply_id, alnaze, ok_cb, false)
end

local reply_id = msg['id']
if  is_momod(msg) then
local alnaz = "فقط برای مدیران🖕🏿😎"
reply_msg(reply_id, alnaze, ok_cb, false)
end

end
return {
patterns ={
  "^[!#/](help)$",
},
run = run
}
end
