--[[ ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 

     ❉❉❉ ฿ᵧ ➣ @PXPP3 
   ➥ CHANNEL ◐ @M0NSTERB0T
    ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 
]] 
do 

local function xviper(msg,matches) 

local reply_id = msg['id'] 
if is_momod(msg) and matches[1]== 'help' then 
  local xviper = [[ ⇒ TeleVent BOT V 2.0 ♺
----------------------
کلیه دستورات با این علامات کار میکنند<#!/>
----------------------
✇home : فهرست اصلی
✇banhelp : دستورات اخراجی
✇locks : دستوراتی حفاظتی
✇Қiks : دستورات حفاظتی اخراج
✇Warns : دستورات حفاظتی اخطار
✇wlchelp : دستورات خوش آمدگویی
♺sudohelp : دستورات سودو 
----------------------
✇channel : تگ کانال ربات
✇support :لینک گروه پشتیبانی
---------------------- ]] 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

local reply_id = msg['id'] 
if not is_momod(msg) then 
local xviper = "فَقًط برای مدیرانَ" 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

end 
return { 
patterns ={ 
  "^[!#/](help)$", 
}, 
run = xviper 
} 
end
