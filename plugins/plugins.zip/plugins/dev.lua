do 

local function run(msg, matches) 

if ( msg.text ) then

  if ( msg.to.type == "user" ) then

     return "آیدی سازنده ربات\n @TeleVentSUDO \n آیدی ربات پیام رسان سودو\n @TeleVentBOT \n آیدی کانال ربات\n @TeleVentTeaM 👾 "
     
  end 
   
end 

-- #DEV @PXPP3

end 

return { 
  patterns = { 
       "(.*)$"
  }, 
  run = run, 
} 

end
