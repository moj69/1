--[[ ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 

     ❉❉❉ ฿ᵧ ➣ @PXPP3 
   ➥ CHANNEL ◐ @INSTAOFFICIAL 
    ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 
]] 
do 
local function run(msg,matches) 
local reply_id = msg['id'] 
if is_momod(msg) and matches[1]== 'kiks' then 
  local xviper = [[⇒MOMSTER BOT V 2.0 ♺
         *↝KICKS↝*
--------------------
➥KICKS :
✇kik media : قفل کیک مدیا
✇unkik media : باز کردن کیک مدیا
✇kik photo : قفل کردن کیک عکس
✇unkik photo : باز کردن کیک عکس
✇kik video : قفل کردن کیک فیلم
✇unkik video : باز کردن کیک فیلم
✇kickaudio : قفل کردن کیک صدا
✇unkik audio : باز کردن کیک صدا
✇kik fwd : قفل کردن کیک فوروارد
✇unkik fwd : باز کردن کیک فوروارد
✇kik link : قفل کردن کیک لینک
✇unkik link : باز کردن کیک لینک
✇kik spamer : قفل کردن کیک اسپم
✇unkik spamer : قفل کردن کیک اسپم
✇kik zahif : لمنع وطرد زواحف
✇unkik zahif : لسماح بالزواحف
✇kik fosh : قفل کردن کیک فوش
✇unkik fosh : باز کردن کیک فوش
-----------------------
Owner Only : 
♺silent : سایلنت کردن یک فرد
♺unsilent : در آوردن یک فرد از سایلنت]] 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

local reply_id = msg['id'] 
if not is_momod(msg) then 
local xviper = "فَقًطِ برای مدیران" 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

end 
return { 
patterns ={ 
  "^[!#/](kiks)$", 
}, 
run = run 
} 
end
