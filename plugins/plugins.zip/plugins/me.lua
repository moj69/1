do

local function run(msg, matches)
if is_sudo(msg) then
     return "(--<b>You Sudo</b>--)".."\n".."(🆔Your ID ) "..msg.from.id.."\n".."(♐️Your Name): "..msg.from.first_name.."\n".."(♒️Your user) @"..msg.from.username.."\n".."(💟GP NAME) "..msg.to.title
end

if is_momod(msg) then 
        return "(--<b>You Admin</b>--)".."\n".."(🆔Your ID ) "..msg.from.id.."\n".."(♐️Your Name): "..msg.from.first_name.."\n".."(♒️Your user) @"..msg.from.username.."\n".."(💟GP NAME) "..msg.to.title  
end
if not is_momod(msg) then 
        return "(--<b>You Member</b>--)".."\n".."(🆔Your ID ) "..msg.from.id.."\n".."(♐️Your Name): "..msg.from.first_name.."\n".."(♒️Your user) @"..msg.from.username.."\n".."(💟GP NAME) "..msg.to.title
end
if is_owner(msg) then 
        return "(--<b>You Owner</b>--)".."\n".."(🆔Your ID ) "..msg.from.id.."\n".."(♐️Your Name): "..msg.from.first_name.."\n".."(♒️Your user) @"..msg.from.username.."\n".."(💟GP NAME) "..msg.to.title
end
end

return {  
  patterns = {
       "^[!#/]([Mm]e)$"
  },
  run = run,
}

end