--[[ ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 

     ❉❉❉ ฿ᵧ ➣ @PXPP3 
   ➥ CHANNEL ◐ @INSTAOFFICIAL 
    ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 
]] 
do 

local function run(msg,matches) 

local reply_id = msg['id'] 
if is_momod(msg) and matches[1]== 'home' then 
  local xviper = [[ ⇒TeleVentPlus+ BOT V 2.0 ♺
            *↝Home↜*
-------------------------
✇id : آیدی شما
✇info : اطلاعات شما
✇gpinfo : اطلاعات گروه
✇tagall : اشاره للجميع
✇voice –تبدیل متن به صدا: -متن مورد نظر
✇sticker : تبدیل عکس به استیکر
✇image : تبدیل استیکر به عکس
✇me : ارسال اطلاعات شما در گروه
✇date :ارسال تاریخ
✇time <زمان: <شهر
✇link : لینک گروه
✇setlink :گروه  تنظیم لینک
✇newlink : ساخت لینک جدید در صورتی که ربات سازنده گروه باشد
✇setname : تنظیم اسم شما
✇setusername : تنظیم یوزرنیم شما
✇setphoto : تنظیم عکس برای گروه
✇rules : لیست قوانین گروه
✇setrules : تنظیم قوانین برای گروه
✇setabout : تنظیم درباره گروه
✇owner : صاحب گروه
✇gbots : لیست ربات هایی که در گروه وجود دارند
✇who : لیست اعضای گروه
✇music <جستجوی موزیک: <اسم
✇setnote : تنظیم پیام یاد آوری شما
✇delnote : پاک کردن پیام یاد آوری
✇mynote : ارسال پیام یاد آوری شما
--------------------
♺Only owner : 
♺promote : ترفیع یک فرد به مدیریت
♺demote : عزل از مدیریت در گروه
♺dele <پاک کردن پیام های گروه: <عدد
♺setbye : تنظیم خداحافظی
♺delbye : پاک کردن پیام خداحافظی
---------------------
Any member :
✇kickme : اخراج از گروه
✇version : ارسال ورژن ربات
✇date : ارسال تاریخ
✶fullinfo : تنظیم اصل یک فرد ↯↯↯↯↯↯↯↯↯↯↯↯↯
☆setnkname : تنظیم اسم فرد
☆setage : تنظیم سن
☆setsex : تنظیم جنس
☆setnote :تنظیم پیام اضافه]] 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

local reply_id = msg['id'] 
if not is_momod(msg) then 
local xviper = "فَقًطِ برای مدیران" 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

end 
return { 
patterns ={ 
  "^[!#/](home)$", 
}, 
run = run 
} 
end
