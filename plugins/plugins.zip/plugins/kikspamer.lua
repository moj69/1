do 

local function run(msg, matches) 
local user = msg.from.id
local chat = msg.to.id
 local spamerx = 'spamerx:'..msg.to.id 
  if redis:get(spamerx) then 
       if not is_momod(msg) then 
          delete_msg(msg.id, ok_cb, true) 
          kick_user(user, chat)
end 
end 
end 

return { 
  patterns = { 
       "^(اسپم)$", 
       "^(fuck)$", 
       "^(در حال اسپم زدن)$", 
       "^(کونی)$", 
       "^(کس ننت)$", 
       "^(کس خواهرت)$", 
       "^(Fuckyou)$", 
       "^(fuckyou)$", 
       "^(جنده)$", 
       "^(تخم سگ)$", 
       "^(پدرسگ)$" 
  }, 
  run = run, 
} 

end 
-- @dev_2