-- made by { @MUSTAFADEV } 
 do 

local function mustafadev(msg, matches) 
   if matches[1] == "phone" then 
      return "اسم😽"..msg.from.print_name.."\nشماره👇🏻📱\n"..(msg.to.phone or "لايوجد") 

   end 

end 

return { 
  patterns = { 
       "^[#!/](phone)$", 
  }, 
  run = mustafadev, 
} 

end 
--[[ 

🌐🌐🌐🌐🌐🌐🌐🌐🌐🌐 
🌐🌐🌐🌐🌐🌐🌐🌐🌐🌐 
Team: oscar 
Dev: MUSTAFADEV 

🌐🌐🌐🌐🌐🌐🌐🌐🌐🌐 
🌐🌐🌐🌐🌐🌐🌐🌐🌐🌐 

--]] 
