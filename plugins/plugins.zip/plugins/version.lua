do 

local function oscar(msg, matches) 
  return [[ 
BOT created by @TeleVentSUDO 👾 
TEAM channel 💡 @TeleVentTeaM 💡 
PM Resan 💠 @TeleVenBOT 💠

〰〰〰〰〰〰〰〰〰〰〰〰 
  .            💠 SUPER TeleVent v2.0 💠 

Created by team ;
@TeleVentSUDO
]] 

end 

return { 
  patterns = { 
       "^[!/#](version)$", 
  }, 
  run = oscar, 
} 

end 
