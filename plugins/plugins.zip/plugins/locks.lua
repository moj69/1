--[[ ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 

     ❉❉❉ ฿ᵧ ➣ @PXPP3 
   ➥ CHANNEL ◐ @INSTAOFFICIAL 
    ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 
]] 
do 

local function run(msg,matches) 

local reply_id = msg['id'] 
if is_momod(msg) and matches[1]== 'locks' then 
  local xviper = [[⇒MOMSTER BOT V 2.0 ♺
         *↝LOCKS↜*
--------------------
➥LOCKS :
✇lock links : قفل لینک
✇unlock links :باز کردن لینک
✇lock fwd : قفل کردن فوروارد
✇unlock fwd : باز کردن قفل فوروارد
✇lock spam : قفل کردن اسپم
✇unlock spam : باز کردن اسپم
✇lock rtl : قفل کردن پیامی ورود و خروج
✇unlock rtl : باز کردن پیام های ورود و خروج
✇lock flood :قفل کردن پیام های تکراری
✇unlock flood : باز کردن پیام های تکراری
✇lock sticker : قفل کردن استیکر
✇unlock sticker : باز کردن استیکر
✇lock file : قفل کردن ارسال فایل
✇unlock file : باز کردن ارسال فایل
✇lock contacts : قفل کردن ارسال شماره
✇unlock contacts : باز کردن ارسال شماره
✇lock strict : قفل کردن تنظیمات سختگیرانه
✇unlock strict : باز کردن تنظیمات سختگیرانه
✇lock member : قفل کردن ورود اعضا
✇unlock member : باز کردن ورود اعضا
✇lock reply : قفل کردن پیام ریپلای
✇unlock reply : باز کردن پیام ریپلای
✇lock emoji : قفل کردن اموجی
✇unlock emoji : باز کردن اموجی
✇lock fosh : قفل کردن فوش
✇unlock fosh : باز کردن فوش
✇lock bots : apiقفل کردن ورود ربات   
✇unlock bots : api باز کردن ورود ربات 
✇lock spamer : قفل کردن اسپم
✇unlock spamer : باز کردن اسپم
✇lock zahif : قفل کردن 
✇unlock zahif : لسماح بالزحف
✇lock join : قفل کردن جوین
✇unlock join : باز کردن جوین 
✇lock leave : قفل لفت اعضا
✇unlock leave :  باز کردن لفت اعضا
✇lock arabic : قفل کردن عربی 
✇unlock arabic : باز کردن عربی
✇lock english : قفل کردن انگلیسی
✇unlock english : باز کردن انگلیسی
✇lock all : قفل همه 
✇unlock all : باز کردن همه
----------------------
◐settings : locks ارسال تنظیمات قفل ها
----------------------
➥MUTES : 
♺mute text : بیصدا کردن متن
♺unmute text : با صدا کردن متن
♺mute all : بی صدا کردن همه
♺unmute all : با صدا کردن همه
❂mute photo : بیصدا کردن عکس
❂unmute photo : با صدا کردن عکس
❂mute audio : بیصدا کردن صدا
❂unmute audio :  باصدا کردن صدا
❂mute video : بیصدا کردن فیلم
❂unmute video : باصدا کردن فیلم
❂mute gifs : بیصدا کردن تصاویر متحرک
❂unmute gifs : با صدا کردن تصاویر متحرک
❂mute documenst : بیصدا کردن پرونده
❂unmute  documents : با صدا کردن پرونده
----------------------
◑muteslist : لیست بیصدا هاMUTES
----------------------
ATTENTION ! : 
❂ and ✇ for ALL ADMINS
♺ FOR OWNER AND SUDO ! ]] 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

local reply_id = msg['id'] 
if not is_momod(msg) then 
local xviper = "فَقًطِ برای مدیران" 
reply_msg(reply_id, xviper, ok_cb, false) 
end 

end 
return { 
patterns ={ 
  "^[!#/](locks)$", 
}, 
run = run 
} 
end
