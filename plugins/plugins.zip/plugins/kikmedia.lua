--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀ 
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ لتحذف حقوق بذمتك🚶🏻 
      #CODS CREATED By ~ @JALAL_ALDON 
      please join to Channel Oscar Team @OSCARBOTv2 
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀ 
--]] 
do 

local function pre_process(msg) 
local jalal = msg['id'] 
  local user = msg.from.id 
  local chat = msg.to.id 
    local oscar = 'mate:'..msg.to.id 
    if redis:get(oscar) and msg.media and not is_momod(msg) then 
    delete_msg(msg.id, ok_cb, false) 
    kick_user(user, chat)

end 

        return msg 
    end 

local function run(msg, matches) 
local jalal = msg['id'] 

    if matches[1] == 'kik media'  and is_momod(msg) then 
                    local oscar = 'mate:'..msg.to.id 
                    redis:set(oscar, true) 
                    local oscar1 = 'کیک مدیا با موفقیت فعال شد🔕'
reply_msg(jalal, oscar1, ok_cb, true) 
elseif matches[1] == 'kik media' and not is_momod(msg) then 
local asdy = 'فقط برای مدیران 🔴' 
reply_msg(jalal, asdy, ok_cb, true) 

    elseif matches[1] == 'unkik media'  and is_momod(msg) then 
      local oscar = 'mate:'..msg.to.id 
      redis:del(oscar) 
    local don = ' کیک مدیا با موفقیت غیرفعال شد🔔' 
reply_msg(jalal, don, ok_cb, true) 
elseif matches[1] == 'unkik media' and not is_momod(msg) then 
local jalal_aldon = 'فقط برای مدیران 🔴' 
reply_msg(jalal, jalal_aldon, ok_cb, true) 
end 
end 

return { 
    patterns = { 
    "^[!/#](kik media)$", 
    "^[!/#](unkik media)$" 
    }, 
run = run, 
    pre_process = pre_process 
} 

end
