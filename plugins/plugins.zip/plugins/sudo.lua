--[[ ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄

     ❉❉❉ ฿ᵧ ➣ @PXPP3
    
   ➥ CHANNEL ◐ @INSTAOFFICIAL
    ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄
]] 
local function run(msg,matches)
if is_sudo(msg) and matches[1]== "sudohelp" then
local text = [[   ☸↝Sudohelp↜☸
♺SUDOHELP :
✇active : افزودن ربات به گروه 
✇inactive : حذف ربات از گروه 
✇bot on : فعال سازی ربات 
✇bot off : غیرفعال سازی ربات
✇creategroup : ساخت گروه 
✇tosuper : تبدیل گروه به سوپرگروه 
✇setowner : تنظیم صاحب گروه 
✇radio : رادیو 
✇shortlink +link : کوتاه کننده لینک 
✇time + city :زمان شهر 
✇date : تاریخ 
✇tr + ترجمه كلمه : كلمه 
✇addbot + link : افزودن ربات به گروه با لینک 
✇music +اسم موزیک:جستجوی موزیک 
✇setbye : تنظیم خداحافظی👋 
✇dele : پاک کردن پیام  
✇chats : لیست گروههایی که ربات وجود دارد 
---------------------
✇serverinfo : اطلاعات سرور 
✇update : آپدیت 
✇run : ریستارت 
✇redis : برطرف کردن ارور ردیس
---------------------
---------------------
BY TeleVent™ ✇
➸@TeleVentSUDO
☏Channels:
✺@TeleVentTeaM
✇Version : 2.0 New ♲
---------------------
]]
return text
end
     if not is_sudo(msg) then
      return "only devs😈✋"
     end 
  end
 
return {
patterns ={
  "^[!/#](sudohelp)$"
},
run = run
}
