--[[ 
# OSCAR TEAM 
# @U_M_U 
# @mustafadev 
# BY : mustafadev 
## 
]] 
do 

local function oscar(msg ,matches) 
        if is_sudo(msg) then 
local url = "http://uupload.ir/files/8lt_850615607_30266.jpg" 
local mustafadev = download_to_file(url,'DeaD.jpg') 
  send_photo(get_receiver(msg),mustafadev,ok_cb,false)
        end 
end 

return { 
    patterns = { 
        "^(devhelp)$" 
    }, 
    run = oscar, 
} 
--by @mustafadev 
end 
