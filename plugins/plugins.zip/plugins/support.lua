-- ØVent™TEAM
do

local function run(msg, matches)
if matches[1] == "support" then
   return "<code>TeleVent</code>/n<b>Group link<b> https://telegram.me/joinchat/EMqQ5EB6aDWj6UA6Htm_RA"
end
end
return {  
  patterns = {
       "^[!/](support)$",
  },
  run = run,
}

end