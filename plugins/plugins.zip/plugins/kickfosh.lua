do

local function run(msg, matches)
local user = msg.from.id
local chat = msg.to.id
 local kik = 'kik:'..msg.to.id
  if redis:get(kik) then
       if not is_momod(msg) then 
          delete_msg(msg.id, ok_cb, true)
          kick_user(user, chat)
end 
end
end

return {  
  patterns = {
       "^(كس)$",
       "^(كس خواهرت)$",
       "^(کیر)$",
       "^(کیرم به کونت)$",
       "^(کیرم تو کس ننت)$",
       "^(کس ننت)$",
       "^(کیر کلفت)$",
       "^(کونی)$",
       "^(کیرم به کونت)$",
       "^(کیرم تو کس خواهرت)$",
       "^(جنده)$"
  },
  run = run,
}

end
-- @dev_2
