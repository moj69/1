do 

local function oscarteam(msg, matches) 
  if matches[1] == "/kik fosh" then 
     local kik = 'kik:'..msg.to.id 
     redis:set(kik, true) 
     return " قفل کیک فوش با موفقیت فعال شد و هرکس از این به بعد فوش بدهد کیک میشود😈✔️ " 
  end 

  if matches[1] == "/unkik fosh" then 
     local kik = 'kik:'..msg.to.id 
     redis:del(kik) 
     return " قفل کیک فوش با موفقیت غیرفعال شد و هرکس از این به بعد فوش بدهد کیک نمیشود😈✔️ " 
  end 

  if matches[1] == "صنع" then 
     --return " cods simsim by @iq_plus and @dev_2 " 

  end 
end 

return { 
  patterns = { 
     "(.*)" 
  }, 
  run = oscarteam, 
} 

end 
-- @dev_2
