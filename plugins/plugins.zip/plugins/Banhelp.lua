--[[ ▄▇▇▇▇▇▇▄▇▇▇▇▇▇▄ 
❉❉❉ ฿ᵧ ➣ @PXPP3 
    ➥ CHANNEL ◐ @INSTAOFFICIAL 
]] 
do 

local function run(msg,matches) 

local reply_id = msg['id'] 
if is_momod(msg) and matches[1]== 'banhelp' then 
  local alnaze = [[    *↝Banhelp↜* 
Banhelp for Group :
✇ban + مسدود کردن یک فرد از گروه : آیدی فرد 
✇unban +فرد در آوردن از لیست مسدود شده ها گروه: آیدی 
✇kick + اخراج ازگروه: آیدی فرد 
❂banlist : لیست مسدود شده ها
Only Sudo :
♺sban + بن جهانی کردن یک فرد : آیدی فرد
♺unsban + آیدی فرد:پاک کردن یک فرد از لیست بن جهانی 
♺gbanlist :لیست بن جهانی 
---------------------
Badwords :
✇add + اضافه کردن یک کلمه به لیست: كلمه 🚫 
✇rm + پاک کردن یه کلمه از لیست: كلمه✅ 
✇badwords : لیست کلمات ممنوع شده 
✇clearbadwords : پاک کردن لیست ممنوع شده ها 
Silents :
✇silent + بیصدا کردن یک فرد : آیدی فرد 
✇silentlist : لیست بیصدا شدگان 
✇clean silentlist : پاک کردن لیست بیصدا شدگان
---------------------]]
reply_msg(reply_id, alnaze, ok_cb, false) 
end 

local reply_id = msg['id'] 
if not is_momod(msg) then 
local alnaz = "فقط برای مدیران🖕🏿😎" 
reply_msg(reply_id, alnaze, ok_cb, false) 
end 

end 
return { 
patterns ={ 
  "^[!#/](banhelp)$", 
}, 
run = run 
} 
end
